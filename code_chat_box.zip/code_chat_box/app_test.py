from flask import Flask, request, jsonify, render_template
import traceback
import requests

# Initialize Flask app
app = Flask(__name__)

# Configure Ollama API
OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "mistral:latest"

# Function to interact with Ollama
def query_ollama(user_message):
    prompt = f"Generate a suitable answer for the following request: '{user_message}'."
    ollama_response = requests.post(
        OLLAMA_URL,
        json={"model": OLLAMA_MODEL, "prompt": prompt, "stream": False},  # stream: False means complete chunk
        headers={"Content-Type": "application/json"}
    )
    return ollama_response.json()

@app.route("/")
def index():
    return render_template("index3.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message")
    try:
        print("User message:", user_message)  # Debugging user message
        
        # Interact with Ollama
        ollama_response_json = query_ollama(user_message)
        print("Ollama response:", ollama_response_json)  # Debug line

        ollama_message = ollama_response_json.get("response", "")

        # Return the results as JSON
        return jsonify({"ollama_response": ollama_message})
    except Exception as e:
        print("Error occurred:", str(e))
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
